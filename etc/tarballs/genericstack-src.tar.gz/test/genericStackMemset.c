#define GENERICSTACK_ZERO_INT_IS_NOT_ZERO_BYTES
#include "genericStack.c"
