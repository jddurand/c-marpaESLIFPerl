#undef GENERICSTACK_DEFAULT_LENGTH
#include "genericStack.c"
