#define GENERICSTACK_DEFAULT_LENGTH 2
#include "genericStack.c"
