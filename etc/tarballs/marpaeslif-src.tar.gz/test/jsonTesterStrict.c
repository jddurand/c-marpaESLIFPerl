#define MARPAESLIF_JSONTESTER_STRICT 1
#include "jsonTester.c"
