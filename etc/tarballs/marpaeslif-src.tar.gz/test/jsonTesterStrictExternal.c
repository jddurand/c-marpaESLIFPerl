#define MARPAESLIF_JSONTESTER_EXTERNAL 1
#include "jsonTesterStrictExternal.h"
#include "jsonTesterStrict.c"
