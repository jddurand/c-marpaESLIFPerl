#define MARPAESLIF_JSONTESTER_STRICT 0
#include "jsonTester.c"
