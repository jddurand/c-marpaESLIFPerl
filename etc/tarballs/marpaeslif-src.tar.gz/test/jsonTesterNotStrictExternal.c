#define MARPAESLIF_JSONTESTER_EXTERNAL 1
#include "jsonTesterNotStrictExternal.h"
#include "jsonTesterNotStrict.c"
