static const char *marpaESLIFJSON_encode_extended_grammars =
  "input ::= INPUT action => ::jsonf\n"
  "INPUT   ~ [\\s\\S]\n"
  ;
