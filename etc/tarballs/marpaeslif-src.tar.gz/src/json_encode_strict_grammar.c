static const char *marpaESLIFJSON_encode_strict_grammars =
  "input ::= INPUT action => ::json\n"
  "INPUT   ~ [\\s\\S]\n"
  ;
