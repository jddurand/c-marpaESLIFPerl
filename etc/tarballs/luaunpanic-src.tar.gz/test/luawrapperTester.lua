-- add two numbers

function add(x, y)
  return x + y
end

-- call abort

function doerror()
  error('Error in lua')
end
